GitHub Pages setup
1. Upload index.html, sitemap.xml, and robots.txt to the root of the GitHub repository giovanni-dalena/Justin-di-Cristofaro (not the wiki repository).
2. In repository Settings > Pages, choose Deploy from a branch, main, /(root), then Save.
3. Confirm the live URL: https://giovanni-dalena.github.io/Justin-di-Cristofaro/
4. In Google Search Console, add this URL prefix property and verify ownership using a supported method.
5. Submit sitemap URL https://giovanni-dalena.github.io/Justin-di-Cristofaro/sitemap.xml and request indexing for the homepage.
Note: The URLs in these files assume the repository is published at the above GitHub Pages address. Update them if you choose a different Pages URL. The robots.txt in a project subdirectory is not a site-root robots directive; it is included for portability but GitHub Pages project sites do not control the github.io root robots.txt.
